const express = require("express");
const router = express.Router();
const groupController = require("../controller/groupController");
const { auth } = require("../middleware/auth");
const { authorizeRole } = require("../middleware/authorizeRole");
// Routes
router.post("/", groupController.createGroup);
router.post('/join-group/:groupCode/:studentId', groupController.joinGroupByCode);
router.post("/:classroomId/:projectId", groupController.createGroup);
router.put('/select-project/:groupId/:facultyProjectId', groupController.selectProjectDefinition);
router.put("/full/:groupId", groupController.updateGroupFull);
router.delete("/:groupId", groupController.deleteGroup);
router.get("/:groupId", groupController.getGroupById);
router.get("/", groupController.getAllGroups);
 
module.exports = router;
