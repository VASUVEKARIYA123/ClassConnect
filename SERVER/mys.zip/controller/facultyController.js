const Faculty = require("../models/Faculty");
const bcrypt = require("bcryptjs");


// Add a new faculty member
const addFaculty = async (req, res) => {
    const { firstname, lastname, email, password, role, rating, domain } = req.body;


    try {
        // Check if faculty with the same email already exists
        const existingFaculty = await Faculty.findOne({ email });
        if (existingFaculty) {
            return res.status(400).json({ message: "Email already exists" });
        }


        // Hash password before saving
        const hashedPassword = await bcrypt.hash(password, 10);


        const faculty = new Faculty({ firstname, lastname, email, password: hashedPassword, role, rating, domain });
        await faculty.save();


        res.status(201).json({ message: "Faculty created successfully" });
    }
    catch (err) {
        res.status(500).json({ message: "Server Error: " + err });
    }
};


// Get faculty by ID
const getFacultyById = async (req, res) => {
    const facultyId = req.params.facultyId;


    try {
        const faculty = await Faculty.findById(facultyId).lean();
        if (!faculty) {
            return res.status(404).json({ message: "Faculty not found" });
        }


        delete faculty.password; // Remove password from response
        res.json(faculty);
    }
    catch (err) {
        res.status(500).json({ message: "Server Error: " + err });
    }
};


// Get all faculty members
const getAllFaculties = async (req, res) => {
    try {
        const faculties = await Faculty.find().select("-password"); // Exclude password
        res.json(faculties);
    }
    catch (err) {
        res.status(500).json({ message: "Server Error: " + err });
    }
};


// Update faculty details
const updateFacultybyadmin = async (req, res) => {
    const facultyId = req.params.facultyId;
    const { firstname, lastname, email, role, rating, domain } = req.body;


    try {
        // Check if another faculty already has the same email
        const existingFaculty = await Faculty.findOne({ email });
        if (existingFaculty && existingFaculty._id.toString() !== facultyId) {
            return res.status(400).json({ message: "Email already exists" });
        }

        const faculty = await Faculty.findByIdAndUpdate(
            facultyId,
            { firstname, lastname, email, role, rating, domain, updatedAt: Date.now() },
            { new: true }
        );


        if (!faculty) {
            return res.status(404).json({ message: "Faculty not found" });
        }


        res.json({ message: "Faculty updated successfully" });
    }
    catch (err) {
        res.status(500).json({ message: "Server Error: " + err });
    }
};

const updateFacultybyfaculty = async (req, res) => {
    const facultyId = req.params.facultyId;
    const { firstname, lastname, email, domain } = req.body;

    try {
        // Check if another faculty already has the same email
        const existingFaculty = await Faculty.findOne({ email });
        if (existingFaculty && existingFaculty._id.toString() !== facultyId) {
            return res.status(400).json({ message: "Email already exists" });
        }

        const faculty = await Faculty.findByIdAndUpdate(
            facultyId,
            { firstname, lastname, email, domain, updatedAt: Date.now() },
            { new: true }
        );

        if (!faculty) {
            return res.status(404).json({ message: "Faculty not found" });
        }

        res.json({ message: "Faculty details updated successfully" });
    }
    catch (err) {
        res.status(500).json({ message: "Server Error: " + err });
    }
};

// Delete faculty by ID
const deleteFacultyById = async (req, res) => {
    const facultyId = req.params.facultyId;


    try {
        const faculty = await Faculty.findByIdAndDelete(facultyId);
        if (!faculty) {
            return res.status(404).json({ message: "Faculty not found" });
        }


        res.json({ message: "Faculty deleted successfully" });
    }
    catch (err) {
        res.status(500).json({ message: "Server Error: " + err });
    }
};

// Change faculty role to admin
const changeRoleToAdmin = async (req, res) => {
    const facultyId = req.params.facultyId;

    try {
        const faculty = await Faculty.findById(facultyId);
        if (!faculty) {
            return res.status(404).json({ message: "Faculty not found" });
        }

        faculty.role = "admin";
        await faculty.save();

        res.json({ message: "Faculty role updated to admin successfully" });
    } catch (err) {
        res.status(500).json({ message: "Server Error: " + err });
    }
};

// Update faculty rating
const updateRating = async (req, res) => {
    const facultyId = req.params.facultyId;
    const { rating } = req.body;

    try {
        const faculty = await Faculty.findByIdAndUpdate(
            facultyId,
            { rating },
            { new: true }
        );

        if (!faculty) {
            return res.status(404).json({ message: "Faculty not found" });
        }

        res.json({ message: "Faculty rating updated successfully" });
    }
    catch (err) {
        res.status(500).json({ message: "Server Error: " + err });
    }
};

module.exports = {
    addFaculty,
    getFacultyById,
    getAllFaculties,
    updateFacultybyadmin,
    updateFacultybyfaculty,
    deleteFacultyById,
    changeRoleToAdmin,
    updateRating
};
