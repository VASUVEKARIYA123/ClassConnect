import React from 'react';
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import CreateClassroom from './components/CreateClassroom/CreateClassroom';
import CreateLabTask from './components/createLabTask/createLabTask';
import Subjects from './components/Subjects';
import TeacherPost from './components/TeacherPost';
import Login from './components/Login/login';
import Logout from './components/Logout/logout';
import ClassroomDetails from "./components/ClassroomDetails/classroomDetails";

export default function Routes() {
  return (
    <BrowserRouter>
      <Switch>
        <Route path="/subject" exact component={Subjects} />
        <Route path="/tasks/:classId" exact component={TeacherPost} />
        <Route path="/create-classroom" exact component={CreateClassroom} />
        <Route path="/create-labtask" exact component={CreateLabTask} />
        <Route path="/" exact component={Login} />
        <Route path="/logout" exact component={Logout} />
        <Route path="/classroom-details/:classId" exact component={ClassroomDetails} />
      </Switch>
    </BrowserRouter>
  );
}
