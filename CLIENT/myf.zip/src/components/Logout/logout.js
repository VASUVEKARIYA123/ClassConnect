import React, { useState } from "react";
import { useHistory } from "react-router-dom";
import styled from "styled-components";
import Header from "../Header";
import DoubtButton from "../common/ButtonDoubt";

// Styled Components
const CardWrapper = styled.div`
  max-width: 50vw;
  margin: 40px auto;
  padding: 20px;
  background: snow;
  border: 1px solid #ccc;
  border-radius: 8px;
  text-align: center;
`;

const Button = styled.button`
  padding: 10px 15px;
  border: none;
  border-radius: 5px;
  background: #dc3545;
  color: white;
  cursor: pointer;
  width: 100%;
  font-size: 1rem;
  transition: background 0.3s;

  &:hover {
    background: #a71d2a;
  }
`;

const Message = styled.p`
  text-align: center;
  font-size: 1rem;
  font-weight: bold;
  margin-top: 10px;
  color: green;
`;

export default function Logout() {
  const [message, setMessage] = useState(null);
  const [success, setSuccess] = useState(false);
  const history = useHistory();

  const handleLogout = async () => {
    setMessage(null);
    try {
      const response = await fetch("http://localhost:5000/api/auth/logout", {
        method: "POST",
        credentials: "include", // Ensures cookies are sent and cleared
      });

      const responseData = await response.json();

      if (response.ok) {
        setMessage("Logout Successful!");
        localStorage.clear();
        setSuccess(true);
        setTimeout(() => {
          history.push("/"); // Redirect to login or home page
        }, 1500);
      } else {
        setMessage(responseData.message || "Logout failed. Please try again.");
        setSuccess(false);
      }
    } catch (error) {
      setMessage("Error: " + error.message);
      setSuccess(false);
    }
  };

  return (
    <>
      <Header />
      <CardWrapper>
        <h2>Logout</h2>
        {message && <Message success={success}>{message}</Message>}
        <Button onClick={handleLogout}>Logout</Button>
      </CardWrapper>
      <DoubtButton />
    </>
  );
}
