import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import Header from "../Header";
import styled from "styled-components";

// Styled Components
const PageWrapper = styled.div`
  max-width: 60vw;
  margin: 40px auto;
  padding: 20px;
  background: white;
  border-radius: 8px;
  box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
`;

const Section = styled.div`
  margin-bottom: 20px;
  padding: 15px;
  background: #f9f9f9;
  border-radius: 8px;
  box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.1);
`;

const Title = styled.h3`
  font-size: 1.4rem;
  color: #007bff;
  margin-bottom: 12px;
`;

const List = styled.ul`
  list-style: none;
  padding: 0;
`;

const ListItem = styled.li`
  padding: 8px;
  border-bottom: 1px solid #ddd;
  font-size: 1rem;
  color: #333;
`;

export default function ClassroomDetails() {
  const { classId } = useParams(); // Get classroom ID from URL
  const [students, setStudents] = useState([]);
  const [faculties, setFaculties] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchClassroomData = async () => {
      try {
        // Fetch students
        const studentRes = await fetch(
          `http://localhost:5000/api/classroom-students/classroom/${classId}`,
          {
            headers: {
              Authorization: `Bearer ${localStorage.getItem("token")}`,
            },
          }
        );

        const studentData = await studentRes.json();

        // Fetch faculties
        const facultyRes = await fetch(
          `http://localhost:5000/api/classroom-faculties/classroom/${classId}`,
          {
            headers: {
              Authorization: `Bearer ${localStorage.getItem("token")}`,
            },
          }
        );
        const facultyData = await facultyRes.json();

        if (studentRes.ok) setStudents(studentData.students || []);
        if (facultyRes.ok) setFaculties(facultyData.faculties || []);
      } catch (error) {
        console.error("Error fetching classroom details:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchClassroomData();
  }, [classId]);

  if (loading) return <p>Loading...</p>;

  return (
    <>
      <Header />
      <PageWrapper>
        <Section>
          <Title>Faculties</Title>
          {faculties.length > 0 ? (
            <List>
              {faculties.map((faculty) => (
                <ListItem key={faculty._id}>
                  {faculty.firstname} {faculty.lastname}
                </ListItem>
              ))}
            </List>
          ) : (
            <p>No faculties found.</p>
          )}
        </Section>

        <Section>
          <Title>Students</Title>
          {students.length > 0 ? (
            <List>
              {students.map((student) => (
                <ListItem key={student._id}>
                  {student.firstname} {student.lastname}
                </ListItem>
              ))}
            </List>
          ) : (
            <p>No students found.</p>
          )}
        </Section>
      </PageWrapper>
    </>
  );
}
