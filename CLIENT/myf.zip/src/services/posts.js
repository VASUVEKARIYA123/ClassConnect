export default [
[
      {
        id_subject: 1,
        teacher: "COMMENTS",
        date: "11 de maio de 2015",
        description: "lalala",
        avatar: "https://avatars1.githubusercontent.com/u/52831621?s=460&u=b268a7dd379b43caf9fad493c58c817dd5d6989e&v=4",
        comments:
        [
          {
            id_comment: 1,
            person_name: "Fulano",
            comment: "Trying to show comments!",
            avatar: "https://static.imasters.com.br/wp-content/uploads/2018/08/06143332/FLEEEXXXX.jpg",
            date: "11 de maio 2020"
          },
          {
            id_comment: 2,
            person_name: "Fulano 2",
            comment: "Trying to show comments! 2",
            avatar: "https://blog.fcamara.com.br/wp-content/uploads/2019/03/1_y6C4nSvy2Woe0m7bWEn4BA-1024x538.png",
            date: "5 de maio 2020"
          },
        ]
      },
      // OTHER POST HER

      {
        id_subject: 1,
        teacher: "COMMENTS",
        date: "11 de maio de 2019",
        description: "POST 2",
        avatar: "https://avatars1.githubusercontent.com/u/52831621?s=460&u=b268a7dd379b43caf9fad493c58c817dd5d6989e&v=4",
        comments:
        [
          {
            id_comment: 1,
            person_name: "Fulano",
            comment: "Trying to show comments!",
            avatar: "https://static.imasters.com.br/wp-content/uploads/2018/08/06143332/FLEEEXXXX.jpg",
            date: "11 de maio 2020"
          },
          {
            id_comment: 2,
            person_name: "Fulano 2",
            comment: "Trying to show comments! 2",
            avatar: "https://blog.fcamara.com.br/wp-content/uploads/2019/03/1_y6C4nSvy2Woe0m7bWEn4BA-1024x538.png",
            date: "5 de maio 2020"
          },
        ]
      },


    ],
      [
        {
        id_subject: 2,
        teacher: "TEST",
        date: "11 de maio de 2015",
        description: "lalala",
        avatar: "https://blog.fcamara.com.br/wp-content/uploads/2019/03/1_y6C4nSvy2Woe0m7bWEn4BA-1024x538.png",

        comments:
        [
          {
            id_comment: 1,
            person_name: "Fulano",
            comment: "Trying to show comments!",
            avatar: "https://avatars1.githubusercontent.com/u/52831621?s=460&u=b268a7dd379b43caf9fad493c58c817dd5d6989e&v=4",
            date: "11 de maio 2020"
          },
          {
            id_comment: 2,
            person_name: "Fulano 2",
            avatar: "https://static.imasters.com.br/wp-content/uploads/2018/08/06143332/FLEEEXXXX.jpg",
            comment: "Trying to show comments! 2",
            date: "5 de maio 2020"
          }
        ]
      },
    ],
      [
        {
        id_subject: 3,
        teacher: "TEST",
        date: "11 de maio de 2015",
        description: "lalala",
        avatar: "https://static.imasters.com.br/wp-content/uploads/2018/08/06143332/FLEEEXXXX.jpg",
        comments:
        [
          {
            id_comment: 1,
            person_name: "Fulano",
            comment: "Trying to show comments!",
            date: "11 de maio 2020"
          }
        ]
      },
    ],
      [
        {
        id_subject: 4,
        teacher: "TEST",
        date: "11 de maio de 2015",
        description: "lalala",
        avatar: "https://avatars1.githubusercontent.com/u/52831621?s=460&u=b268a7dd379b43caf9fad493c58c817dd5d6989e&v=4",
        comments:
        [
          {
            id_comment: 1,
            person_name: "Fulano",
            comment: "Trying to show comments!",
            avatar: "https://avatars1.githubusercontent.com/u/52831621?s=460&u=b268a7dd379b43caf9fad493c58c817dd5d6989e&v=4",
            date: "11 de maio 2020"
          }
        ]
      },
    ],
      [
        {
        id_subject: 5,
        teacher: "TEST",
        date: "11 de maio de 2015",
        description: "lalala",
        avatar: "https://blog.fcamara.com.br/wp-content/uploads/2019/03/1_y6C4nSvy2Woe0m7bWEn4BA-1024x538.png",
        comments:
        [
          {
            id_comment: 1,
            person_name: "Fulano",
            comment: "Trying to show comments!",
            avatar: "https://static.imasters.com.br/wp-content/uploads/2018/08/06143332/FLEEEXXXX.jpg",
            date: "11 de maio 2020"
          }
        ]
      },
    ],
      [
        {
        id_subject: 6,
        teacher: "TEST",
        date: "11 de maio de 2015",
        description: "lalala",
        avatar: "https://static.imasters.com.br/wp-content/uploads/2018/08/06143332/FLEEEXXXX.jpg",
        comments:
        [
          {
            id_comment: 1,
            person_name: "Fulano",
            comment: "Trying to show comments!",
            avatar: "https://avatars1.githubusercontent.com/u/52831621?s=460&u=b268a7dd379b43caf9fad493c58c817dd5d6989e&v=4",
            date: "11 de maio 2020"

          }
        ]
      },


      {
        id_subject: 6,
        teacher: "Tarefa sobre Matematica",
        date: "11 de maio de 2020",
        description: "Resolva as questões mandadas no e-mail!",
        avatar: "https://static.imasters.com.br/wp-content/uploads/2018/08/06143332/FLEEEXXXX.jpg",
        comments:
        [
          {
            id_comment: 1,
            person_name: "Fulano",
            comment: "Já resolvi tudo professor!",
            avatar: "https://avatars1.githubusercontent.com/u/52831621?s=460&u=b268a7dd379b43caf9fad493c58c817dd5d6989e&v=4",
            date: "11 de maio 2020"

          }
        ]
      },

    ],
];

